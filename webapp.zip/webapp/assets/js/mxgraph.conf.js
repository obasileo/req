mxBasePath = '/req/assets';
mxImageBasePath = '/req/assets/images';